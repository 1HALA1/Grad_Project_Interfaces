import 'package:flutter/material.dart';

import 'Pages/Congrats.dart';
import 'Pages/Forgotpassword.dart';
import 'Pages/Landpage.dart';
import 'Pages/Login.dart';
import 'Pages/Managerinterface.dart';
import 'Pages/Passwordchangedsuccessfully.dart';
import 'Pages/RegistrationRequestsPage.dart';
import 'Pages/Report.dart';
import 'Pages/Resetpassword.dart';
import 'Pages/Signup.dart';
import 'Pages/Speechtotext.dart';
import 'Pages/Userinterface.dart';
import 'Pages/VoicePage.dart';



void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: "/LandPage",
      routes: {
        "/LandPage": (context) =>  LandPage(),
        "/Signup": (context) => const Signup(),
        "/Login": (context) => const Login(),
        "/Forgotpassword": (context) => Forgotpassword(),
        '/Resetpassword': (context) => Resetpassword(),
        "/Passwordchangedsuccessfully": (context) =>
            Passwordchangedsuccessfully(),

        "/Userinterface": (context) => const Userinterface(),
        "/Managerinterface": (context) => const Managerinterface(),
        "/Report": (context) => Report(),
        "/RegistrationRequestsPage": (context) => const RegistrationRequestsPage(),
        "/Congrats": (context) => const Congrats(),
        "/Speechtotext": (context) => const Speechtotext(),
        "/VoicePage": (context) => const VoicePage(),



      },
    );
  }
}
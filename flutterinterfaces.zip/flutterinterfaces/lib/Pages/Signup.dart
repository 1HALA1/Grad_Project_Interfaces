import 'package:flutter/material.dart';
import 'package:flutterinterfaces/Widgets/Apptextfield.dart';
import '../Widgets/Appbuttons.dart';

class Signup extends StatefulWidget {
  const Signup({Key? key}) : super(key: key);

  @override
  _SignupState createState() => _SignupState();
}

const List<String> list = <String>['Student','Teacher', 'staff'];

class _SignupState extends State<Signup> {
  bool isManager = false; // Assume the user is not a manager (initially)
  String? dropdownValue;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          iconTheme: IconThemeData(color: Colors.black),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context),
          ),
          backgroundColor: Colors.grey[200],
        ),
        backgroundColor: Colors.grey[200],
        body: SingleChildScrollView(
          child: Center(
            child: Container(
              color: Colors.grey[200],
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 20),
                  Text(
                    "Hello!",
                    style: TextStyle(
                        fontSize: 30,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  Text(
                    "Create Your Account",
                    style: TextStyle(
                        fontSize: 30,
                        color: Colors.black,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 21),

                     Apptextfield(
                      hintText: "Enter your First and Last name",
                      icon: Icons.person,
                    ),

                  SizedBox(height: 25),
                  Apptextfield(
                    hintText: " User ID",
                    icon: Icons.person,
                  ),
                  SizedBox(height: 25,),

                     Apptextfield(
                      hintText: "Enter your phone number",
                      icon: Icons.phone,
                    ),

                  SizedBox(height: 25),

                    Apptextfield(
                      hintText: "Enter your email address",
                      icon: Icons.email_outlined,
                    ),
                  SizedBox(height: 25),
                  Apptextfield(
                    hintText: "Enter your password",
                    icon: Icons.lock_outline_rounded,
                  ),
                  SizedBox(height: 25),
                  Apptextfield(
                    hintText: "Confirm your password",
                    icon: Icons.lock_outline_rounded,
                  ),
                  SizedBox(height: 25),


                       SizedBox(
                         width: 400.0,
                         child: Container(

                          padding: const EdgeInsets.symmetric(horizontal: 20.0),
                          decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.3),
                                spreadRadius: 2,
                                blurRadius: 3,
                                offset: Offset(0, 2),
                              ),
                            ],
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8.0),

                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              value: dropdownValue,
                              isExpanded: false,


                              hint: Text('Select your role'),
                              //style: TextStyle(color:Color(0xFF2F66F5)),
                              onChanged: (String? newValue) {
                                setState(() {
                                  dropdownValue = newValue;
                                });
                              },
                              items: list.map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                            ),
                          ),
                                             ),
                       ),


                  SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Are you a manager?"),
                      SizedBox(width: 100),
                      AnimatedSwitcher(
                        duration: Duration(milliseconds: 300),
                        transitionBuilder:
                            (Widget child, Animation<double> animation) {
                          return ScaleTransition(
                            scale: animation,
                            child: child,
                          );
                        },
                        child: Switch(
                          key: UniqueKey(),
                          value: isManager,
                          onChanged: (bool newValue) {
                            setState(() {
                              isManager = newValue;
                            });
                          },
                          activeColor: Color(0xFF2D2689),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 17),
                  Appbuttons(
                    text: "signup",
                    backgroundColor: Color(0xFF2D2689),
                    onPressed: () {
                      // Check if user is a manager and then navigate
                      if (isManager) {
                        Navigator.pushNamed(context, '/Managerinterface');
                      } else {
                        Navigator.pushNamed(context, '/VoicePage');
                      }
                    },
                  ),
                  SizedBox(height: 33),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Already have an account? "),
                      GestureDetector(
                        onTap: () {
                          Navigator.pushNamed(context, "/Login");
                        },
                        child: Text(
                          " Log in",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 17),
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 27),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';


import '../Widgets/Appbuttons.dart';

class Userinterface extends StatefulWidget {
  const Userinterface({Key? key}) : super(key: key);

  @override
  _UserinterfaceState createState() => _UserinterfaceState();
}

class _UserinterfaceState extends State<Userinterface>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(duration: Duration(seconds: 1), vsync: this);
    _animation = Tween<double>(begin: 0, end: 400)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
    _controller.forward();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBodyBehindAppBar: true, // Extend body behind the AppBar
        appBar: AppBar(
          backgroundColor: Colors.transparent, // Make AppBar transparent
          elevation: 0.0, // Remove shadow
          iconTheme: IconThemeData(color: Color (0xFFE3AC96)),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('lib/assets/Photo/background1.jpg'), // Replace with your image path
              fit: BoxFit.cover, // Cover the entire screen
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AnimatedBuilder(
                    animation: _animation,
                    builder: (context, child) {
                      return Container(
                        width: _animation.value,
                        height: _animation.value,
                        child: Image.asset('lib/assets/Photo/LOGO01.png'),

                      );
                    },
                  ),
                  SizedBox(height: 30),
                  SizedBox(
                    child: Appbuttons(
                      text: "Request Authentication",
                      routeName: '/VoicePage',
                    ),
                  ),
                  SizedBox(height: 40),
                  SizedBox(
                    child: Appbuttons(
                      text: "Log Out",
                      routeName: '/LandPage',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}